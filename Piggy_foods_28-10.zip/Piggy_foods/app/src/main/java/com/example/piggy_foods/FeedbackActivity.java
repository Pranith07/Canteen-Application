package com.example.piggy_foods;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.piggy_foods.databinding.ActivityFeedbackBinding;
import com.example.piggy_foods.databinding.ActivityMainBinding;

public class FeedbackActivity extends AppCompatActivity {

    ActivityFeedbackBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFeedbackBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        DBHelper helper = new DBHelper(this);

        LayerDrawable stars = (LayerDrawable) binding.ratingbar.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_ATOP);
//String.valueOf(rt.getRating())
        binding.gotooptions.setEnabled(false);
        binding.submitRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.ratingbar != null){
                boolean isRatingInserted = helper.insertRating(
                        String.valueOf(binding.ratingbar.getRating()),
                        binding.ratingName.getText().toString(),
                        binding.ratingEid.getText().toString(),
                        binding.ratingComments.getText().toString()


                );
                    binding.submitRating.setEnabled(true);


                if (isRatingInserted) {
                    Toast.makeText(FeedbackActivity.this, "Thanks for your valuable feedback!!", Toast.LENGTH_SHORT).show();
                    binding.submitRating.setEnabled(false);
                    binding.gotooptions.setEnabled(true);
                }
            }else{
                    Toast.makeText(FeedbackActivity.this, "Please give feedback...", Toast.LENGTH_SHORT).show();
                }


        }
        });

        binding.gotooptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i =new Intent(FeedbackActivity.this,Options.class);
                startActivity(i);
                finish();
            }
        });


    }
}