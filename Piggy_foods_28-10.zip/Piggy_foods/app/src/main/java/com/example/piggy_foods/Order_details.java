package com.example.piggy_foods;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationChannelCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.piggy_foods.databinding.ActivityOrderDetailsBinding;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Order_details extends AppCompatActivity {
//    ActionBar actionBar = getSupportActionBar();

//    @Override
//    public void setTitle(int titleId) {
//        super.setTitle("Adding to cart");
//    }

    int count = 1;
    int count1 = 1;
    String dishtype;
    String deliverytype;
    int price;
    public ActivityOrderDetailsBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Spinner spinnerType = (Spinner) findViewById(R.id.spinnerType);
        binding = ActivityOrderDetailsBinding.inflate(getLayoutInflater());
//        setContentView(R.layout.activity_order_details);
        setContentView(binding.getRoot());
        DBHelper helper = new DBHelper(this);

        if (getIntent().getIntExtra("type",0) == 1){


//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
//            NotificationChannel channel = new NotificationChannel("Order Success Notification", "Order Success Notification", NotificationManager.IMPORTANCE_DEFAULT);
//            NotificationManager manager = getSystemService(NotificationManager.class);
//            manager.createNotificationChannel(channel);
//        }

        final int image = getIntent().getIntExtra("image", 0);
        final String name = getIntent().getStringExtra("name");
        final int price = Integer.parseInt(getIntent().getStringExtra("price"));
        final String description = getIntent().getStringExtra("description");
        Timestamp created_at = null;

//        if(name == "CAKE"){
//            binding.spinnerTypeTV.setVisibility(View.INVISIBLE);
////            binding.spinnerType.setVisibility(View.INVISIBLE);
//        }

        binding.selectedItemImage.setImageResource(image);
        binding.selectedItemName.setText(name);
        binding.PriceAmount.setText(String.format("%d", price));
        binding.selectedItemDescription.setText(description);

            ArrayList<String> spinnerList = new ArrayList<String>();
            spinnerList.add("Select");
            spinnerList.add("Veg");
            spinnerList.add("Non-Veg");

            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,spinnerList);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
            binding.spinnerType.setAdapter(spinnerAdapter);
            binding.spinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    binding.spinnerType.setSelection(i);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });

            Log.d("name",""+name);

            if(name.equals("CAKE") || name.equals("STRAWBERRY PIE") || name.equals("COFFEE")){
                    binding.spinnerTypeTV.setVisibility(View.GONE);
//                    binding.spinnerTypeTV.setEnabled(false);
            binding.spinnerType.setVisibility(View.GONE);
        }

            ArrayList<String> spinnerDeliveryList = new ArrayList<String>();
            spinnerDeliveryList.add("Select");
            spinnerDeliveryList.add("PickUp");
            spinnerDeliveryList.add("Desk");

            ArrayAdapter<String> spinnerAdapterdelivey = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,spinnerDeliveryList);
            spinnerAdapterdelivey.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
            binding.spinnerDelivery.setAdapter(spinnerAdapterdelivey);
            binding.spinnerDelivery.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    binding.spinnerDelivery.setSelection(i);

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });


        binding.minusbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count > 0){
                    count --;
                    binding.incrementnumber.setText(""+count);
                    if(count == 0)
                    {
                        Toast.makeText(Order_details.this,"Please select atleast one item.",Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            }
        });

        binding.plusbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    count ++;
                    binding.incrementnumber.setText(""+count);
            }
        });

        binding.incrementnumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            public void afterTextChanged(Editable s) {
                binding.PriceAmount.setText(""+(Integer.valueOf(price)*count));
            }
        });




        binding.placeorderbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dishtype = (String) binding.spinnerType.getSelectedItem();
                deliverytype = (String) binding.spinnerDelivery.getSelectedItem();
                if(deliverytype == "Desk") {
                    final EditText edittext = new EditText(new ContextThemeWrapper(Order_details.this,R.style.AlertDialogCustom));
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(Order_details.this);
                    alertDialog.setTitle("Enter the Desk details. (Desk no)");
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    edittext.setLayoutParams(lp);
                    alertDialog.setView(edittext);
                    alertDialog.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            //What ever you want to do with the value
                            String YouEditTextValue = edittext.getText().toString();
                            Intent intent = new Intent(Order_details.this,MainActivity.class);
                            startActivity(intent);
                             finish();
                        }
                    });
                    alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            //
                            dialog.cancel();
//
                        }
                    });
                    AlertDialog dialog = alertDialog.create();
                    dialog.show();
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.black));
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.black));
                }else{
                    Intent intent = new Intent(Order_details.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }

                String imageveg = "drawable://" + R.drawable.veg_logo;
                String imagenonveg = "drawable://" + R.drawable.non_veg_logo;

                if(dishtype == "Veg"){
//                    String nameAppend = "(Veg)";
                    if (binding.PersonName!=null){
                        boolean isInserted = helper.insertOrder(
                                binding.PersonName.getText().toString(),
                                dishtype,
                                deliverytype,
                                Integer.valueOf(price)*count,
                                image,
                                description,
                                Integer.parseInt(binding.incrementnumber.getText().toString()),
                                name + " (Veg)"

                        );
                        if (isInserted) {
                            Toast.makeText(Order_details.this, "Added to cart Successfully..", Toast.LENGTH_SHORT).show();
//                            SharedPreferences prefs = getSharedPreferences("type", MODE_PRIVATE);
//                            SharedPreferences.Editor edit = prefs.edit();
//                            edit.putString("Veg", dishtype );
//                            edit.commit();
                        } else {
                            Toast.makeText(Order_details.this, "Data Not Inserted", Toast.LENGTH_SHORT).show();
                        }
                }}else if(dishtype == "Non-Veg"){


                Log.d("mode",""+dishtype);
                Log.d("mode",""+deliverytype);
                if (binding.PersonName!=null) {
                    boolean isInserted = helper.insertOrder(
                            binding.PersonName.getText().toString(),
                            dishtype,
                            deliverytype,
//                        binding.deliveryMode.getText().toString(),
                            Integer.valueOf(price) * count,
                            image,
                            description,
                            Integer.parseInt(binding.incrementnumber.getText().toString()),
                            name + " (Non-Veg)"

                    );
                    if (isInserted) {
                        Toast.makeText(Order_details.this, "Added to cart Successfully..", Toast.LENGTH_SHORT).show();
//                        SharedPreferences prefsnonveg = getSharedPreferences("typenonveg", MODE_PRIVATE);
//                        SharedPreferences.Editor edit = prefsnonveg.edit();
//                        edit.putString("Non-Veg", dishtype + " nv" );
//                        edit.commit();
                    } else {
                        Toast.makeText(Order_details.this, "Data Not Inserted", Toast.LENGTH_SHORT).show();
                    }
                }


            }else{


                    Log.d("mode",""+dishtype);
                    Log.d("mode",""+deliverytype);
                    if (binding.PersonName!=null) {
                        boolean isInserted = helper.insertOrder(
                                binding.PersonName.getText().toString(),
                                dishtype,
                                deliverytype,
//                        binding.deliveryMode.getText().toString(),
                                Integer.valueOf(price) * count,
                                image,
                                description,
                                Integer.parseInt(binding.incrementnumber.getText().toString()),
                                name

                        );
                        if (isInserted) {
                            Toast.makeText(Order_details.this, "Added to cart Successfully..", Toast.LENGTH_SHORT).show();
//                            Orders.typeLogo = dishtype;
                        } else {
                            Toast.makeText(Order_details.this, "Data Not Inserted", Toast.LENGTH_SHORT).show();
                        }
                    }


                }

//                Intent intent = new Intent(Order_details.this,Order_placed_splash.class);
//                Bundle bundle = new Bundle();
//                bundle.putString("name", binding.PersonName.getText().toString());
//                intent.putExtras(bundle);
//                startActivity(intent);
//                finish();

//                Intent intent = new Intent(Order_details.this,MainActivity.class);
//                startActivity(intent);
//                finish();

//                NotificationCompat.Builder builder = new NotificationCompat.Builder(Order_details.this, "Order Success Notification")
//                        .setSmallIcon(R.drawable.ordertick)
//                        .setContentTitle("Order Success Notification")
//                        .setContentText("")
//                        .setStyle(new NotificationCompat.BigTextStyle()
//                                .bigText("Hey " + binding.PersonName.getText().toString() + ", your order has been placed successfully. Please wait until we prepare your dish...."))
//                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//                        .setAutoCancel(true);
//
//                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Order_details.this);
//                managerCompat.notify(1, builder.build());

                SharedPreferences prefs = getSharedPreferences("type", MODE_PRIVATE);
                SharedPreferences.Editor edit = prefs.edit();
                edit.putString("Veg", dishtype );
                edit.commit();
            }
        });


    }else{
//            Log.d("tag",getIntent().getStringExtra("price"));
            int id = getIntent().getIntExtra("id",0);
//            price = Integer.parseInt(getIntent().getStringExtra("price"));
            Cursor  cursor = helper.getOrderById(id);
            int image = cursor.getInt(4);
            binding.selectedItemImage.setImageResource(image);
            binding.selectedItemName.setText(cursor.getString(7));
            binding.PriceAmount.setText(String.format("%d", cursor.getInt(3)));
            binding.selectedItemDescription.setText(cursor.getString(5));

            binding.PersonName.setText(cursor.getString(1));
//            spinnerType.setText(cursor.getString(2));
            binding.incrementnumber.setText(cursor.getString(6));

            binding.placeorderbutton.setText("Update Order..");
            binding.placeorderbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   boolean isUpdated=helper.updateOrder(
                            binding.PersonName.getText().toString(),
                           binding.spinnerType,
//                           Integer.valueOf(price)*count1,
//                           (Integer.parseInt(binding.PriceAmount.getText().toString())/price)*count1,
                           Integer.parseInt(binding.PriceAmount.getText().toString()),
                            image,
                            binding.selectedItemDescription.getText().toString(),
                            Integer.parseInt(binding.incrementnumber.getText().toString()),
                            binding.selectedItemName.getText().toString(),
                            id
                    );

                    if (isUpdated) {
                        Toast.makeText(Order_details.this, "Order Updated Successfully..", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Order_details.this, "Data Not Inserted", Toast.LENGTH_SHORT).show();
                    }
//                }else if(binding.PersonPhone.length() > 10 & binding.PersonPhone.length() < 10){
//                    Toast.makeText(Order_details.this, "Enter Valid mobile number..", Toast.LENGTH_SHORT).show();
//                }else if(binding.PersonPhone.length()==0){
//                    Toast.makeText(Order_details.this, "Enter the number..", Toast.LENGTH_SHORT).show();
//                }
                }
            });

//            TextView updatedPrice = binding.PriceAmount;
            binding.minusbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (count1 > 0){
                        count1 --;
                        binding.incrementnumber.setText(""+count1);
                    }
                }
            });

            binding.plusbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    count1 ++;
                    binding.incrementnumber.setText(""+count1);
                }
            });

            binding.incrementnumber.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }
                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }
                public void afterTextChanged(Editable s) {
//                    binding.PriceAmount.setText(""+Integer.parseInt(binding.PriceAmount.getText().toString())*count1);
//                    binding.PriceAmount.setText((Integer.valueOf(price)*count1));
                }
            });
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bar_both, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Orders:
                startActivity(new Intent(Order_details.this, OrderFinal.class));
                finish();
                break;

            case R.id.Home:
                startActivity(new Intent(Order_details.this, Options.class));
                finish();
                break;

            case R.id.Cart:
                startActivity(new Intent(Order_details.this, Orders.class));
                finish();
                break;

        }
        return super.onOptionsItemSelected(item);

    }
}