package com.example.piggy_foods;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.piggy_foods.Adapters.ImageAdapter;

public class Options extends AppCompatActivity {

    SharedPreferences sh;
    LinearLayout SliderDots;
    private int dotscount;
    private ImageView[] dots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        Button menu = (Button) findViewById(R.id.menu_button);
        Button cart_btn = (Button) findViewById(R.id.cart_btn);
        Button myorders = (Button) findViewById(R.id.myorders);
        Button aboutus = (Button) findViewById(R.id.aboutus);
        Button profile = (Button) findViewById(R.id.profile_button);
        Button feedback = (Button) findViewById(R.id.feedback_btn);
        ImageButton leftNav = (ImageButton) findViewById(R.id.left_nav);
        ImageButton rightNav = (ImageButton) findViewById(R.id.right_nav);
        TextView marqueetv = (TextView) findViewById(R.id.marqueetv);
        marqueetv.setSelected(true);

        ViewPager gallery = (ViewPager) findViewById(R.id.gallery);

        SliderDots = (LinearLayout) findViewById(R.id.SliderDots);

        ImageAdapter imageAdapter = new ImageAdapter(this);
        gallery.setAdapter(imageAdapter);

//        leftNav = (ImageButton) view.findViewById(R.id.left_nav);
//        rightNav = (ImageButton) view.findViewById(R.id.right_nav);

// Images left navigation
        leftNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int tab = gallery.getCurrentItem();
//                if (tab > 0) {
//                    tab--;
//                    gallery.setCurrentItem(tab);
//                } else if (tab == 0) {
//                    gallery.setCurrentItem(tab);
//                }
                gallery.arrowScroll(View.FOCUS_LEFT);
            }
        });

        // Images right navigation
        rightNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int tab = gallery.getCurrentItem();
//                tab++;
//                gallery.setCurrentItem(tab);
                gallery.arrowScroll(View.FOCUS_RIGHT);
            }
        });

//        public void toggleArrowVisibility(boolean isAtZeroIndex, boolean isAtLastIndex) {
//            if(isAtZeroIndex)
//                leftNav.setVisibility(View.INVISIBLE);
//            else
//                leftNav.setVisibility(View.VISIBLE);
//            if(isAtLastIndex)
//                rightNav.setVisibility(View.INVISIBLE);
//            else
//                rightNav.setVisibility(View.VISIBLE);
//
//        }

        rightNav.setBackgroundColor(Color.TRANSPARENT);
        leftNav.setBackgroundColor(Color.TRANSPARENT);

//        dotscount = imageAdapter.getCount();
//        dots = new ImageView[dotscount];
//
//        for(int i = 0; i < dotscount; i++){
//            dots[i] = new ImageView(this);
//            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
//            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
//            params.setMargins(8, 0, 8, 0);
//            SliderDots.addView(dots[i], params);
//        }
//        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));

//        gallery.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//
//                for(int i = 0; i< dotscount; i++){
//                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
//                }
//
//                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));
//
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//        });
//        gallery.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(Options.this,MainActivity.class);
//                startActivity(intent);
//            }
//        });




        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,MainActivity.class);
                startActivity(intent);
//                finish();
            }
        });

        cart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,Orders.class);
                startActivity(intent);
//                finish();
            }
        });

        myorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,OrderFinal.class);
                startActivity(intent);
//                finish();
            }
        });

        aboutus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,AboutUs.class);
                startActivity(intent);
//                finish();
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,Profile_activity.class);
                startActivity(intent);
//                finish();
            }
        });

        feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Options.this,FeedbackActivity.class);
                startActivity(intent);
//                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Options.this);
        alertDialog.setTitle("Are you sure you want to exit?");
        alertDialog.setIcon(R.drawable.warning);
        alertDialog.setMessage("Then click YES to exit.");
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });
        alertDialog.setNeutralButton("Need help??", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Options.this,"How can i help you, please try calling this number to get help.",Toast.LENGTH_SHORT).show();

                        Uri u = Uri.parse("tel:" + "9030838073");

                        Intent dail = new Intent(Intent.ACTION_DIAL, u);

                        try
                        {

                            startActivity(dail);
                        }
                        catch (SecurityException s)
                        {

                            Toast.makeText(Options.this, "An error occurred", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
                });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();

                    }
                });
                AlertDialog dialog = alertDialog.create();
        dialog.show();
        dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.black));
        dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.black));
        dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(getResources().getColor(R.color.black));

//                .show().getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.black));
    }
}