package com.example.piggy_foods;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.piggy_foods.Adapters.OrderAdapter;
import com.example.piggy_foods.Models.OrdersModel;
import com.example.piggy_foods.databinding.ActivityOrdersBinding;

import java.util.ArrayList;
import java.util.Collections;

public class Orders extends AppCompatActivity {
//    static String typeLogo = "";
    ActivityOrdersBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrdersBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ImageView typeLogo = (ImageView) findViewById(R.id.typeLogo);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("Order Success Notification", "Order Success Notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }


//        list.add(new OrdersModel(R.drawable.burger, "BURGER", "150","123456"));
//        list.add(new OrdersModel(R.drawable.pizza, "PIZZA", "220","123456"));
//        list.add(new OrdersModel(R.drawable.cake, "CAKE", "450","123456"));
//        list.add(new OrdersModel(R.drawable.strawberry_pie, "STRAWBERRY PIE", "120","123456"));

        DBHelper helper = new DBHelper(this);
        ArrayList<OrdersModel> list = helper.displayOrders();


        OrderAdapter adapter = new OrderAdapter(list,this);
        binding.orderRecyclerView.setAdapter(adapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.orderRecyclerView.setLayoutManager(layoutManager);



//        Log.d("test",""+typeLogo);
//        if(typeLogo.equals("Veg"))
//        {
//            Log.d("tag","Veg");
//            typeLogo.setImageResource(R.drawable.veg_logo);
//        }else{
//            typeLogo.setImageResource(R.drawable.non_veg_logo);
//        }

        SharedPreferences bb = getSharedPreferences("type", 0);
        String type = bb.getString("Veg", "");
        Log.d("tag",""+type);

//        if(type.equals("Veg")){
////            typeLogo.getResources().getDrawable(R.drawable.veg_logo);
//            Uri uri = ;
//            typeLogo.setImageURI(uri);
//        }
//        }else if(type.equals("Non-Veg")){
////            typeLogo.setImageResource(R.drawable.non_veg_logo);
//            typeLogo.getResources().getDrawable(R.drawable.non_veg_logo);
//        }

//        SharedPreferences bb2 = getSharedPreferences("typenonveg", 0);
//        String nonveg = bb2.getString("Non-Veg", "");
//        Log.d("tag",""+nonveg);

        binding.clearCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                helper.dropCartOnClear();
                list.clear();
                adapter.notifyDataSetChanged();
                binding.checkoutBtn.setEnabled(false);
            }
        });

        if(list.isEmpty()){
            binding.checkoutBtn.setEnabled(false);
            Toast.makeText(Orders.this,"Please add items to the cart from the menu.",Toast.LENGTH_SHORT).show();
        }

        binding.checkoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                helper.copyfromCarttoOrdersDB();
                Toast.makeText(Orders.this,"Successfull",Toast.LENGTH_SHORT).show();
                helper.dropCartOnClear();
                list.clear();
                adapter.notifyDataSetChanged();
                binding.checkoutBtn.setEnabled(false);

//                Intent intent = new Intent(Orders.this,delivery_mode.class);
                Intent intent = new Intent(Orders.this,Order_placed_splash.class);
//                Bundle bundle = new Bundle();
//                bundle.putString("name", binding.PersonName.getText().toString());
//                intent.putExtras(bundle);
                startActivity(intent);
                finish();


                NotificationCompat.Builder builder = new NotificationCompat.Builder(Orders.this, "Order Success Notification")
                        .setSmallIcon(R.drawable.ordertick)
                        .setContentTitle("Order Success Notification")
                        .setContentText("")
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText("Hey your order has been placed successfully. Please wait until we prepare your dish...."))
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Orders.this);
                managerCompat.notify(1, builder.build());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_homebtn, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Home:
                startActivity(new Intent(Orders.this, Options.class));
                finish();
                break;

            case R.id.Orders:
                startActivity(new Intent(Orders.this, OrderFinal.class));
                finish();
                break;

            case R.id.Menu:
                startActivity(new Intent(Orders.this, MainActivity.class));
                finish();
                break;

        }
        return super.onOptionsItemSelected(item);

    }
}