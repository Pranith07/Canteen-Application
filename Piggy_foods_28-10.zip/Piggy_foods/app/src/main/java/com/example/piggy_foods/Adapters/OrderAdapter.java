package com.example.piggy_foods.Adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggy_foods.DBHelper;
import com.example.piggy_foods.Login1;
import com.example.piggy_foods.Models.OrdersModel;
import com.example.piggy_foods.Order_details;
import com.example.piggy_foods.Orders;
import com.example.piggy_foods.Profile_activity;
import com.example.piggy_foods.R;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.viewholder>{

    ArrayList<OrdersModel> list;
    Context context;
    DBHelper helper;

    public OrderAdapter(ArrayList<OrdersModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.sample_order,parent,false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
    final OrdersModel model = list.get(position);
    helper = new DBHelper(context.getApplicationContext());
    holder.orderImage.setImageResource(model.getOrderImage());
    holder.soldItemName.setText(model.getSoldItemName());
    holder.order_no.setText(model.getOrder_no());
    holder.orderPrice.setText(model.getPrice());
    holder.cust_name.setText(model.getCust_name());
    holder.quantity.setText(model.getQuantity());
    holder.created_at.setText(model.getCreated_at());
    holder.delivery_mode.setText(model.getDelivery_mode());
    String x = helper.veg_non_veg_check(model.getType());

    if (x.equals("Veg")){
//        holder.soldItemName.setTextColor(Color.parseColor("#006400"));
        holder.typeLogo.setImageResource(R.drawable.veg_logo);
    }else if (x.equals("Non-Veg")){
//        holder.soldItemName.setTextColor(Color.parseColor("#FFFF00"));
        holder.typeLogo.setImageResource(R.drawable.non_veg_logo);
    }

    holder.itemView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(context, Order_details.class);
            intent.putExtra("id",Integer.parseInt(model.getOrder_no()));
//            intent.putExtra("price",Integer.parseInt(model.getPrice()));
            intent.putExtra("type",2);
            context.startActivity(intent);
        }
    });

    holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View view) {
            new AlertDialog.Builder(context)
                    .setTitle("Are you sure you want to Delete the item from the cart?")
                    .setIcon(R.drawable.warning)
                    .setMessage("Then click YES to delete.")
                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                         DBHelper helper = new DBHelper(context);
            if(helper.deleteOrder(model.getOrder_no()) > 0){
                Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(context, Orders.class);
//                context.startActivity(intent);
////                finish();
            }else {
                Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
            }

                        }
                    })
                    .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();

                        }
                    }).show();

            return false;
        }
    });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class viewholder extends RecyclerView.ViewHolder {

        ImageView orderImage,typeLogo;
        TextView soldItemName, orderPrice, order_no, cust_name, quantity, created_at, delivery_mode;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            orderImage = itemView.findViewById(R.id.order_image);
            soldItemName = itemView.findViewById(R.id.order_itemName);
            order_no = itemView.findViewById(R.id.order_no);
            orderPrice = itemView.findViewById(R.id.orderPrice);
            cust_name = itemView.findViewById(R.id.orderbelongsto);
            quantity = itemView.findViewById(R.id.quantityno);
            created_at = itemView.findViewById(R.id.created_at);
            delivery_mode = itemView.findViewById(R.id.delivery_mode_tv);
            typeLogo = itemView.findViewById(R.id.typeLogo);

        }
    }
}
