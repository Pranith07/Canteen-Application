package com.example.piggy_foods;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.piggy_foods.Adapters.MainAdapter;
import com.example.piggy_foods.Models.MainModel;
import com.example.piggy_foods.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    MainAdapter searchAdapter;
    ArrayList<MainModel> list = new ArrayList<>();
    MainAdapter adapter = new MainAdapter(list, this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        ArrayList<MainModel> list = new ArrayList<>();
        list.add(new MainModel(R.drawable.burger_2, "BURGER", "150", "Yummy delicious burger with wheat bread!!"));
        list.add(new MainModel(R.drawable.pizza, "PIZZA", "220", "Pizza, dish of Italian origin consisting of a flattened disk of bread dough topped with some combination of olive oil, oregano, tomato, olives, mozzarella or other cheese, and many other ingredients, baked quickly!!"));
        list.add(new MainModel(R.drawable.paneer_tikka, "PANEER TIKKA", "180", "Paneer tikka is an Indian dish made from chunks of paneer marinated in spices and grilled in a tandoor.!!"));
        list.add(new MainModel(R.drawable.paneer_65, "PANEER 65", "180", "Paneer 65 is a spicy Hyderabadi appetizer made with paneer, flour, yogurt, curry leaves and spices.!!"));
        list.add(new MainModel(R.drawable.coffee, "COFFEE", "80", "Coffee is a brewed drink prepared from roasted coffee beans, the seeds of berries from certain Coffea species.!!"));
        list.add(new MainModel(R.drawable.cake_2, "CAKE", "450", "A cake is a sweet food made by baking a mixture of flour, eggs, sugar, and fat in an oven!!"));
        list.add(new MainModel(R.drawable.strawberry_pie, "STRAWBERRY PIE", "120", "Strawberry pie is a dessert food consisting mainly of strawberries!!"));


//        list.add(new MainModel(R.drawable.icecream, "ICE CREAM", "60", "Ice cream is a frozen dairy dessert obtained by freezing the ice cream mix with continuous agitation. It contains milk products, sweetening materials, stabilizers, colors, flavors, and egg products!!"));


//        searchAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);

//        MainAdapter adapter = new MainAdapter(list, this);
        binding.recyclerview.setAdapter(adapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.recyclerview.setLayoutManager(layoutManager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_orderbtn, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Enter here to search for an item.");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Orders:
                startActivity(new Intent(MainActivity.this, OrderFinal.class));
                finish();
                break;

            case R.id.Cart:
                startActivity(new Intent(MainActivity.this, Orders.class));
                finish();
                break;
        }
            return super.onOptionsItemSelected(item);

    }

//    @Override
//    public void onBackPressed() {
//        new AlertDialog.Builder(MainActivity.this)
//                .setTitle("@@@EXIT@@@")
//                .setIcon(R.drawable.warning)
//                .setMessage("Do not want to taste deliciousness??? Then click YES to exit!!!!")
//                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        finish();
//                    }
//                })
//                .setNeutralButton("Need help??", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        Toast.makeText(MainActivity.this,"How can i help you??",Toast.LENGTH_SHORT).show();
//                    }
//                })
//                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        dialogInterface.cancel();
//                    }
//                }).show();
//    }
}