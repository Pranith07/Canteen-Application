package com.example.piggy_foods.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.example.piggy_foods.MainActivity;
import com.example.piggy_foods.Models.MainModel;
import com.example.piggy_foods.Options;
import com.example.piggy_foods.Order_details;
import com.example.piggy_foods.R;

import java.util.ArrayList;

public class ImageAdapter extends PagerAdapter {
    ArrayList<MainModel> list;
    private Context mContext;
    private int[] mImageIds = new int[]{R.drawable.virtusalogo2,R.drawable.burger_2, R.drawable.coffee, R.drawable.cake_2, R.drawable.strawberry_pie};

    public ImageAdapter(Context context){
        mContext = context;
    }



    @Override
    public int getCount() {
        return mImageIds.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        ImageView imageView = new ImageView(mContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setImageResource(mImageIds[position]);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(position == 0){
                    Toast.makeText(mContext, "Welcome to Virtusa Canteen!!", Toast.LENGTH_SHORT).show();
                }
                else{


                Intent intent = new Intent(mContext, MainActivity.class);
                mContext.startActivity(intent);

//                    MainModel model = list.get(position);
//                    Intent intent = new Intent(mContext, Order_details.class);
//                    intent.putExtra("image",model.getImage());
////                    intent.putExtra("name",model.getName());
////                    intent.putExtra("price",model.getPrice());
////                    intent.putExtra("description",model.getDescription());
//                    mContext.startActivity(intent);
                }
            }
        });

        container.addView(imageView,0);
        return imageView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((ImageView)object);
    }
}
