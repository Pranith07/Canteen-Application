package com.example.piggy_foods;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.piggy_foods.Adapters.OrderFinalAdapter;
import com.example.piggy_foods.Models.OrderFinalModel;
import com.example.piggy_foods.Models.OrdersModel;
import com.example.piggy_foods.databinding.ActivityOrderFinalBinding;

import java.util.ArrayList;
import java.util.Calendar;

public class OrderFinal extends AppCompatActivity {
    ActivityOrderFinalBinding binding;
    String dateod;
    DBHelper helper = new DBHelper(this);
    DatePickerDialog.OnDateSetListener mDateSetListener;
    ArrayList<OrderFinalModel> list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrderFinalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        ArrayList<OrderFinalModel> list = helper.displayOrders_final();

        OrderFinalAdapter adapter = new OrderFinalAdapter(list,this);
        binding.orderRecyclerView.setAdapter(adapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.orderRecyclerView.setLayoutManager(layoutManager);

        TextView mDisplayDate = binding.tvDate;
        TextView text = binding.text;
//        DatePickerDialog.OnDateSetListener mDateSetListener;
//        DatePickerDialog.OnDateSetListener finalMDateSetListener = mDateSetListener;
        mDisplayDate.setBackgroundColor(Color.WHITE);
        text.setBackgroundColor(Color.WHITE);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(
                        OrderFinal.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d("tag", "onDateSet: mm-dd-yyy: " + month + "-" + day + "-" + year);
                if (month < 10 && day < 10) {
                    dateod = year + "-0" + month + "-0" + day;
                } else if (month < 10) {
                    dateod = year + "-0" + month + "-" + day;
                } else if (day < 10) {
                    dateod = year + "-" + month + "-0" + day;
                } else {
                    dateod = year + "-" + month + "-" + day;
                }

                mDisplayDate.setText(dateod);
                list1 = helper.displayOrders_date(dateod);
                OrderFinalAdapter adapter = new OrderFinalAdapter(list1,getApplicationContext());
                binding.orderRecyclerView.setAdapter(adapter);
                // GetDataintoArray(dateod);
                // GetCartValueFromDB();
            }
        };

//        if(list.isEmpty()){
//            binding.completeOrder.setEnabled(false);
//            Toast.makeText(OrderFinal.this,"Please checkout from cart first.",Toast.LENGTH_SHORT).show();
//        }
//        binding.completeOrder.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                helper.dropOrdersOnComplete();
//                list.clear();
//                adapter.notifyDataSetChanged();
//                binding.completeOrder.setEnabled(false);
//                Intent i = new Intent(OrderFinal.this,FeedbackActivity.class);
//                startActivity(i);
//                finish();
//
//                Toast.makeText(OrderFinal.this,"Order completed successfully...",Toast.LENGTH_SHORT).show();
//            }
//        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_orderfinal, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Home:
                startActivity(new Intent(OrderFinal.this, Options.class));
                finish();
                break;

            case R.id.Refresh:
                startActivity(new Intent(OrderFinal.this, OrderFinal.class));
                finish();
                break;

        }
        return super.onOptionsItemSelected(item);

    }

}