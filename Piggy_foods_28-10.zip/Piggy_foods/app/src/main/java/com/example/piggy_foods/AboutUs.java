package com.example.piggy_foods;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        Button mapbtn = (Button) findViewById(R.id.mapbtn);

        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse("geo:17.420979088134533,78.34426415384281?q="+ "Virtusa Piggy foods.");
//                        String uri = String.format(Locale.ENGLISH, "http://maps.google.com/maps?q=loc:%f,%f", 28.43242324,77.8977673);

//                        String uri = "http://maps.google.com/maps?f=d&hl=en&sMysore="+12.3106368+","+76.5656492
//                                +"&dOoty="+11.4118505+","+76.658402;
//                        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(uri));
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                    }
                }, 1000);
            }
        });
    }
}