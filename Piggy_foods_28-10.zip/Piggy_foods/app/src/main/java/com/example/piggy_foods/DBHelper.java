package com.example.piggy_foods;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import com.example.piggy_foods.Models.OrderFinalModel;
import com.example.piggy_foods.Models.OrdersModel;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Random;

public class DBHelper extends SQLiteOpenHelper {
    final static String DB_Name = "piggy.db";
    final static  int DB_Version = 1;
//    public String veg_non_veg_check;

    public DBHelper(@Nullable Context context) {
        super(context, DB_Name, null, DB_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "create table orders " +
                        "(id integer primary key autoincrement," +
                        "cust_name text," +
                        "type text," +
                        "delivery_mode text," +
                        "price int," +
                        "image int," +
                        "description text," +
                        "quantity int," +
                        "itemname text)"

        );

        sqLiteDatabase.execSQL(
                "create table orders_final " +
                        "(id integer ," +
                        "cust_name text," +
                        "type text," +
                        "delivery_mode text," +
                        "price int," +
                        "image int," +
                        "description text," +
                        "quantity int," +
                        "itemname text," +
                        "created_at Timestamp)"


        );

//        sqLiteDatabase.execSQL(
//                "create table orders_delivery " +
//                        "(id integer primary key autoincrement," +
//                        "cust_name text," +
//                        "type text," +
//                        "price int," +
//                        "image int," +
//                        "description text," +
//                        "quantity int," +
//                        "itemname text)"
//        );


        sqLiteDatabase.execSQL(
                "create table ratings " +
                        "(rating text," +
                        "rating_name text," +
                        "rating_eid text," +
                        "rating_comments text)"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists orders");
//        sqLiteDatabase.execSQL("drop table if exists orders_delivery");
        sqLiteDatabase.execSQL("drop table if exists orders_final");
        sqLiteDatabase.execSQL("drop table if exists ratings");
        onCreate(sqLiteDatabase);

    }

    public boolean insertOrder(String cust_name, String type, String delivery_mode, int price, int image, String description, int quantity, String itemname){
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("cust_name", cust_name);
        values.put("type", String.valueOf(type));
        values.put("delivery_mode", delivery_mode);
        values.put("price", price);
        values.put("image", image);
        values.put("description", description);
        values.put("quantity", quantity);
        values.put("itemname", itemname);
//        values.put("created_at", String.valueOf(created_at));
////        database.insert("orders", null, STRFTIME('%Y-%m-%d', 'NOW'));
//        database.execSQL("INSERT INTO orders VALUES(cust_name,cust_phone,price,image,description,quantity,itemname,STRFTIME('%Y-%m-%d', 'NOW'))");
        long id = database.insert("orders",null,values);
        if (id<=0){
            return false;
        } else {
            return true;
        }
//        return true;
    }

    public void dropCartOnClear()
    {
        SQLiteDatabase database1 = getReadableDatabase();
        database1.execSQL(
                "drop table if exists orders"
        );
        database1.execSQL(
                "create table orders " +
                        "(id integer primary key autoincrement," +
                        "cust_name text," +
                        "type text," +
                        "delivery_mode text," +
                        "price int," +
                        "image int," +
                        "description text," +
                        "quantity int," +
                        "itemname text)"

        );

    }

    public void dropOrdersOnComplete()
    {
        SQLiteDatabase database1 = getReadableDatabase();
        database1.execSQL(
                "drop table if exists orders_final"
        );
        database1.execSQL(
                "create table orders_final " +
                        "(id integer ," +
                        "cust_name text," +
                        "type text," +
                        "delivery_mode text," +
                        "price int," +
                        "image int," +
                        "description text," +
                        "quantity int," +
                        "itemname text," +
                        "created_at Timestamp)"

        );

    }

    public void copyfromCarttoOrdersDB()
    {
        SQLiteDatabase database1 = getReadableDatabase();
        Random r = new Random();
        int i1 = r.nextInt(999 - 100);
        String sql1 = "INSERT INTO orders_final SELECT " + i1 + ",cust_name,type,delivery_mode,price,image,description,quantity,itemname,STRFTIME('%Y-%m-%d', 'NOW') FROM orders";
        database1.execSQL(sql1);

    }

//    public void addDeliveryMode()
//    {
//        SQLiteDatabase database1 = getReadableDatabase();
//        String sql1 = "ALTER TABLE orders ADD pickup text";
//        database1.execSQL(sql1);
//    }

    public ArrayList<OrdersModel> displayOrders(){
        ArrayList<OrdersModel> orders = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select id,itemname,image,price,cust_name,quantity,delivery_mode,type from orders",null);
        if (cursor.moveToFirst()){
            do {
                OrdersModel model = new OrdersModel();
                model.setOrder_no(cursor.getInt(0) +"");
                model.setSoldItemName(cursor.getString(1));
                model.setOrderImage(cursor.getInt(2));
                model.setPrice(cursor.getInt(3)+"");
                model.setCust_name(cursor.getString(4)+"");
                model.setQuantity(cursor.getString(5)+"");
                model.setDelivery_mode(cursor.getString(6)+"");
                model.setType(cursor.getString(7)+"");
                orders.add(model);
            }while (cursor.moveToNext());
        }

        cursor.close();
        database.close();
        return orders;
    }

    public ArrayList<OrderFinalModel> displayOrders_final(){
        ArrayList<OrderFinalModel> orders_final = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select id,itemname,image,price,cust_name,quantity,created_at,delivery_mode from orders_final",null);
        if (cursor.moveToFirst()){
            do {
                OrderFinalModel model = new OrderFinalModel();
                model.setOrder_no(cursor.getInt(0) +"");
                model.setSoldItemName(cursor.getString(1));
                model.setOrderImage(cursor.getInt(2));
                model.setPrice(cursor.getInt(3)+"");
                model.setCust_name(cursor.getString(4)+"");
                model.setQuantity(cursor.getString(5)+"");
                model.setCreated_at(cursor.getString(6)+"");
                model.setDelivery_mode(cursor.getString(7)+"");
                orders_final.add(model);
            }while (cursor.moveToNext());
        }

        cursor.close();
        database.close();
        return orders_final;
    }

    public ArrayList<OrderFinalModel> displayOrders_date(String dateod){
        ArrayList<OrderFinalModel> orders_final = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select id,itemname,image,price,cust_name,quantity,created_at,delivery_mode from orders_final where date(created_at) = date(?)",new String[]{dateod});
        if (cursor.moveToFirst()){
            do {
                OrderFinalModel model = new OrderFinalModel();
                model.setOrder_no(cursor.getInt(0) +"");
                model.setSoldItemName(cursor.getString(1));
                model.setOrderImage(cursor.getInt(2));
                model.setPrice(cursor.getInt(3)+"");
                model.setCust_name(cursor.getString(4)+"");
                model.setQuantity(cursor.getString(5)+"");
                model.setCreated_at(cursor.getString(6)+"");
                model.setDelivery_mode(cursor.getString(7)+"");
                orders_final.add(model);
            }while (cursor.moveToNext());
        }

        cursor.close();
        database.close();
        return orders_final;
    }

//    public ArrayList<OrderFinalModel> displayOrders_orderno(String order_no){
//        ArrayList<OrderFinalModel> orders_final = new ArrayList<>();
//        SQLiteDatabase database = this.getWritableDatabase();
//        Cursor cursor = database.rawQuery("select id,itemname,image,price,cust_name,quantity,created_at from orders_final where id = ?",new String[]{order_no});
//        if (cursor.moveToFirst()){
//            do {
//                OrderFinalModel model = new OrderFinalModel();
//                model.setOrder_no(cursor.getInt(0) +"");
//                model.setSoldItemName(cursor.getString(1));
//                model.setOrderImage(cursor.getInt(2));
//                model.setPrice(cursor.getInt(3)+"");
//                model.setCust_name(cursor.getString(4)+"");
//                model.setQuantity(cursor.getString(5)+"");
//                model.setCreated_at(cursor.getString(6)+"");
//                orders_final.add(model);
//            }while (cursor.moveToNext());
//        }

//        cursor.close();
//        database.close();
//        return orders_final;
//    }



    public Cursor getOrderById(int id){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("select * from orders where id = "+ id,null);

        if(cursor!=null){
            cursor.moveToNext();
        }
//        cursor.close();
//        database.close();
        return cursor;
    }

    public boolean updateOrder(String cust_name, Spinner type, int price, int image, String description, int quantity, String itemname, int id){
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("cust_name", cust_name);
        values.put("type", String.valueOf(type));
        values.put("price", price);
        values.put("image", image);
        values.put("description", description);
        values.put("quantity", quantity);
        values.put("itemname", itemname);
//        values.put("created_at", String.valueOf(created_at));
        long row = database.update("orders",values,"id="+id,null);
        if (row<=0){
            return false;
        } else {
            return true;
        }
    }
    
    public int deleteOrder(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("orders","id="+id,null);
    }

    public boolean insertRating(String rating, String rating_name, String rating_eid, String rating_comments){
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("rating", rating);
        values.put("rating_name", rating_name);
        values.put("rating_eid", rating_eid);
        values.put("rating_comments", rating_comments);
        long id = database.insert("ratings",null,values);
        if (id<=0){
            return false;
        } else {
            return true;
        }
    }

    public String veg_non_veg_check(String type)
    {
        SQLiteDatabase readobj=getReadableDatabase();
        Cursor cursor=null;
        String x = "0";
        if(readobj!=null)
        {
            cursor=readobj.rawQuery("SELECT type FROM orders where type=?",new String[]{type});
        }
        while(cursor.moveToNext())
        {
            x=cursor.getString(0);
            //Log.d("x value",x);
        }
        return String.valueOf(x);
    }
}
