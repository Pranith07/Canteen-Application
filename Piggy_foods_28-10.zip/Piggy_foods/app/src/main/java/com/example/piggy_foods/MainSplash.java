package com.example.piggy_foods;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;

public class MainSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final long SPLASH_SCREEN_TIME_OUT = 3500;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_splash);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                SharedPreferences sh=getSharedPreferences("User_details", MODE_PRIVATE);
//                spno.setText();
                if(TextUtils.isEmpty(sh.getString("PhNo", ""))){
                    Intent i=new Intent(MainSplash.this,
                            Login1.class);
                    //Intent is used to switch from one activity to another.
                    startActivity(i);
                    //invoke the SecondActivity.
                    finish();
                    //the current activity will get finished.
                }else{
                    Intent i=new Intent(MainSplash.this,
                            Options.class);
                    //Intent is used to switch from one activity to another.
                    startActivity(i);
                    //invoke the SecondActivity.
                    finish();
                    //the current activity will get finished.

                }

            }
        }, SPLASH_SCREEN_TIME_OUT);
    }
}