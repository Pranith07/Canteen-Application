package com.example.piggy_foods.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggy_foods.DBHelper;
import com.example.piggy_foods.Models.OrderFinalModel;
import com.example.piggy_foods.Models.OrdersModel;
import com.example.piggy_foods.Order_details;
import com.example.piggy_foods.R;

import java.util.ArrayList;

public class OrderFinalAdapter extends RecyclerView.Adapter<OrderAdapter.viewholder> {

    ArrayList<OrderFinalModel> list;
    Context context;

    public OrderFinalAdapter(ArrayList<OrderFinalModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.sample_order,parent,false);
        return new OrderAdapter.viewholder(view);
    }

    @NonNull
    @Override
    public void onBindViewHolder(@NonNull OrderAdapter.viewholder holder, int position) {
        final OrderFinalModel model = list.get(position);
        holder.orderImage.setImageResource(model.getOrderImage());
        holder.soldItemName.setText(model.getSoldItemName());
        holder.order_no.setText(model.getOrder_no());
        holder.orderPrice.setText(model.getPrice());
        holder.cust_name.setText(model.getCust_name());
        holder.quantity.setText(model.getQuantity());
        holder.created_at.setText(model.getCreated_at());
        holder.delivery_mode.setText(model.getDelivery_mode());


//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Intent intent = new Intent(context, Order_details.class);
////                intent.putExtra("id", Integer.parseInt(model.getOrder_no()));
////            intent.putExtra("price",Integer.parseInt(model.getPrice()));
////                intent.putExtra("type", 2);
////                context.startActivity(intent);
//
//                DBHelper helper = new DBHelper(context.getApplicationContext());
//                helper.displayOrders_date(model.getOrder_no());
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class viewholder extends RecyclerView.ViewHolder {

        ImageView orderImage;
        TextView soldItemName, orderPrice, order_no, cust_name, quantity, created_at, delivery_mode;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            orderImage = itemView.findViewById(R.id.order_image);
            soldItemName = itemView.findViewById(R.id.order_itemName);
            order_no = itemView.findViewById(R.id.order_no);
            orderPrice = itemView.findViewById(R.id.orderPrice);
            cust_name = itemView.findViewById(R.id.orderbelongsto);
            quantity = itemView.findViewById(R.id.quantityno);
            created_at = itemView.findViewById(R.id.created_at);
            delivery_mode = itemView.findViewById(R.id.delivery_mode_tv);

        }
    }
}