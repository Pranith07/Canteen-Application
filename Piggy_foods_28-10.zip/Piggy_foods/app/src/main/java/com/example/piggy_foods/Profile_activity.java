package com.example.piggy_foods;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Profile_activity extends AppCompatActivity {

    SharedPreferences sh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        TextView spno = (TextView) findViewById(R.id.spno1);
        Button logout = (Button) findViewById(R.id.logout);


        sh=getSharedPreferences("User_details", MODE_PRIVATE);
        spno.setText(sh.getString("PhNo", ""));

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                            new AlertDialog.Builder(Profile_activity.this)
                            .setTitle("Are you sure you want to Logout?")
                            .setIcon(R.drawable.warning)
                            .setMessage("Then click YES to Logout.")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    sh.edit().clear().apply();
                                    Intent intent = new Intent(Profile_activity.this,Login1.class);
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();

                                }
                            }).show();

            }
        });
    }
}