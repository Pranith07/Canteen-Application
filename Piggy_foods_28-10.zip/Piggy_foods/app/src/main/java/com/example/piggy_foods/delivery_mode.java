package com.example.piggy_foods;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

import com.example.piggy_foods.databinding.ActivityDeliveryModeBinding;

public class delivery_mode extends AppCompatActivity {

    ActivityDeliveryModeBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDeliveryModeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        int selectedId = binding.radiogroupid.getCheckedRadioButtonId();
//
//        RadioButton selectedRadioButton = (RadioButton)findViewById(selectedId);

//        binding.pickupTime.setEnabled(false);
//        binding.deskTime.setEnabled(false);
//        binding.deskLocation.setEnabled(false);

//        if(binding.radiogroupid.getCheckedRadioButtonId() == -1){
//            binding.pickupTime.setEnabled(false);
//            binding.deskTime.setEnabled(false);
//            binding.deskLocation.setEnabled(false);
//        }
//
//        else{
//
//            if (binding.pickup.isChecked()){
//                binding.pickupTime.setEnabled(true);
//            }else{
//                binding.deskTime.setEnabled(true);
//                binding.deskLocation.setEnabled(true);
//            }
//        }

        DBHelper helper = new DBHelper(this);

        binding.deliverymodeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });
    }
}