package com.example.piggy_foods.Models;

public class OrdersModel {
    int orderImage;
    String soldItemName, orderPrice, order_no, cust_name, quantity, created_at, delivery_mode,type;

    public OrdersModel() {
        this.orderImage = orderImage;
        this.soldItemName = soldItemName;
        this.orderPrice = orderPrice;
        this.order_no = order_no;
        this.cust_name = cust_name;
        this.quantity = quantity;
        this.created_at = created_at;
        this.delivery_mode = delivery_mode;
        this.type = type;
    }

    public int getOrderImage() {
        return orderImage;
    }

    public void setOrderImage(int orderImage) {
        this.orderImage = orderImage;
    }

    public String getSoldItemName() {
        return soldItemName;
    }

    public void setSoldItemName(String soldItemName) {
        this.soldItemName = soldItemName;
    }

    public String getPrice() {
        return orderPrice;
    }

    public void setPrice(String price) {
        this.orderPrice = price;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getCust_name () {
        return cust_name;
    }

    public void setCust_name(String cust_name) {
        this.cust_name = cust_name;
    }

    public String getQuantity () {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getCreated_at () {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getDelivery_mode () {
        return delivery_mode;
    }

    public void setDelivery_mode(String delivery_mode) {
        this.delivery_mode = delivery_mode;
    }

    public String getType () {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
