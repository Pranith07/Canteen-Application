package com.example.piggy_foods;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        EditText n1 = (EditText) findViewById(R.id.n1);
        EditText n2 = (EditText) findViewById(R.id.n2);
        EditText n3 = (EditText) findViewById(R.id.n3);
        EditText n4 = (EditText) findViewById(R.id.n4);
        EditText n5 = (EditText) findViewById(R.id.n5);
        EditText n6 = (EditText) findViewById(R.id.n6);
        TextView otp_phno = (TextView) findViewById(R.id.otp_phno);
        Button verify = (Button) findViewById(R.id.verify);

        n1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void afterTextChanged(Editable s) {

                if (s.length() == 1) {
                    n2.requestFocus();
                }
            }
        });
        n2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void afterTextChanged(Editable s) {

                if (s.length() == 1) {
                    n3.requestFocus();
                }
            }
        });

        n3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void afterTextChanged(Editable s) {

                if (s.length() == 1) {
                    n4.requestFocus();
                }
            }
        });

        n4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void afterTextChanged(Editable s) {

                if (s.length() == 1) {
                    n5.requestFocus();
                }
            }
        });

        n5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void afterTextChanged(Editable s) {

                if (s.length() == 1) {
                    n6.requestFocus();
                }
            }
        });

        Bundle b2 = getIntent().getExtras();
        String number= b2.getString("PhNo");
        otp_phno.setText("+91"+number);

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login2.this,Options.class);
                startActivity(intent);
                finish();
            }
        });
    }

}